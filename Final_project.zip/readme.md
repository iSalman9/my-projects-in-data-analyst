# (Flights)
## by (Salman Almufarrij)


## Flights Dataset

> These dataset for 2000 year that  are information about all aspects of the flight for the US, such as departure time, arrival time, departure airport, and arrival airport,and this dataset Contains 5683047 entries and 22 columns.
I get Those dataset from http://stat-computing.org/dataexpo/2009/the-data.html .


## Summary of Findings

* Univariate Exploration

The sixth day  was decreased of number of flights from the rest of the days.

The number of flight cancellations is  is very low.

The most common type of Unique Carrier is a WN , DL carrier.


* Bivariate Exploration
From month 7 to the end(month 12)  there are   increase in the number of flights from the rest of the months of the year.

The UniqueCarrier have a Max Distance is CO and UniqueCarrier that have a Min Distance is AA.

In month 1 and month 12 the cancellation rate was higher than  the rest of the months of the year.

The UniqueCarrier UA  had the highest rate of cancellation.


* Multivariate Exploration
The Airport_Dest ALT was DL Carrier was have large of number of flights and the Airport_Dest ORD the AA,UA UniqueCarrier's was have the same number of flights with same Cancelled.

The US UniqueCarrier was have a max Number of flights , the WN UniqueCarrier have a min Number of flights  from the rest of the UniqueCarrier.

The number of flights in DL UniqueCarrier are greater than US UniqueCarrier,and the tall duration of max number of flights is in mothe five from day one to day five.


## Key Insights for Presentation

The most popular type from Unique Carrier is the WN and DL carrier. The reason may be due to their spread and presence in all countries. They have many resources and a large number of employees.

The UniqueCarrier with  a maximum distance is CO and the reason is that it is carried to countries very far from  the starting area, and UniqueCarrier which has a lower distance is AA, and the reason is that it is carried to countries close to the starting area.

The UniqueCarrier US  have number of flights greater than US UniqueCarrier , and we note increasing  number of flights in ends days of week in all month and particulary in month Twelve.











